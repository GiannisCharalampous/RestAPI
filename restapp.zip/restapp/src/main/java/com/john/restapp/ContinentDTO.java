package com.john.restapp;

import javax.validation.constraints.NotBlank;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ContinentDTO {

	@NotBlank(message = "hi")
	private int id;

	@NotBlank(message = "hi")
	private String name;

	public ContinentDTO(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public ContinentDTO() {

	}

	public int getId() {
		
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		
		return name ;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Continent [id=" + id + ", name=" + name + "]";
	}
}
