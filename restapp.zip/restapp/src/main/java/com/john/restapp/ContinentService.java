package com.john.restapp;

import java.sql.SQLException;
import java.util.logging.Logger;

import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.process.internal.RequestScoped;

@RequestScoped
@Path("continents")
public class ContinentService {

	@Inject
	ContinentDAO dao = new ContinentDAO();

	private static final Logger logger = Logger.getLogger(ContinentService.class.getName());

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllContinents() throws SQLException {
		if (dao.getAllContinents().isEmpty()) {
			logger.info("No data available");
			return Response.status(404).build();
		} else {
			logger.info("Successfuly retrive all Continents");
		}
		return Response.ok("All Continents have retrieved " + dao.getAllContinents()).build();
	}

	@GET
	@Path("continent/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getContinent(@Valid @PathParam("id") int id) throws SQLException {
		if (dao.getContinent(id).getId() == 0) {
			logger.info("No data available");
			return Response.status(404).build();
		} else {
			logger.info("Successfuly retrive " + dao.getContinent(id));
		}
		return Response.ok("Successfuly retrive " + dao.getContinent(id)).build();
	}

	@POST
	@Path("continent/")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response createContinent(@Valid ContinentDTO continent) throws SQLException {
		if (continent.getName() == null || continent.getName().isEmpty() || continent.getName().isEmpty()) {
			return Response.status(404).build();
		}
		System.out.println(continent);
		dao.createContinent(continent);

		return Response.ok("New Continent has created " + continent).build();
	}

	@PUT
	@Path("continent/")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateContinent(@Valid ContinentDTO continent) throws SQLException {
		System.out.println(continent);
		if (dao.getContinent(continent.getId()).getId() == 0) {
			if (continent.getName() == null || continent.getName().isEmpty() || continent.getName().isEmpty()) {
				return Response.status(404).build();
			}
			dao.createContinent(continent);
		} else {
			dao.updateContinent(continent);
		}
		return Response.ok("Continent has updated " + continent).build();
	}

	@DELETE
	@Path("continent/{id}")
	public Response deleteContinent(@PathParam("id") int id) throws SQLException {
		ContinentDTO continent = dao.getContinent(id);
		if (continent.getId() != 0) {
			dao.deleteContinent(id);
		} else {
			return Response.status(404).build();
		}

		return Response.ok("Continent has deleted " + continent).build();
	}
}
