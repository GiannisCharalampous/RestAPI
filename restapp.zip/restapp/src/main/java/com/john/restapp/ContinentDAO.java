package com.john.restapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Path;

@Path("Continents")
public class ContinentDAO {

	Connection con = null;

	public ContinentDAO() {
		String url = "jdbc:mysql://localhost:3306/exports?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
		String username = "root";
		String password = "root";

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ContinentDTO getContinent(int id) throws SQLException {
		String sql = "select * from continent where id=" + id;
		ContinentDTO continent = new ContinentDTO();

		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		try {
			if (rs.next()) {
				continent.setId(rs.getInt(1));
				continent.setName(rs.getString(2));
			}
		} finally {
			// Avoid leak if an exception was thrown in createStatement
			if (st == null) {
				con.close();
			}
		}
		return continent;
	}

	public List<ContinentDTO> getAllContinents() throws SQLException {
		List<ContinentDTO> continents = new ArrayList<>();
		String sql = "select * from continent";

		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		try {
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				ContinentDTO continent = new ContinentDTO(id, name);

				continents.add(continent);
			}
		} finally {
			// Avoid leak if an exception was thrown in createStatement
			if (st == null) {
				con.close();
			}
		}

		return continents;

	}

	public void createContinent(ContinentDTO continent) throws SQLException {
		String sql = "insert into continent values (?,?)";
		PreparedStatement st = con.prepareStatement(sql);
		try {
			st.setInt(1, continent.getId());
			st.setString(2, continent.getName());
			st.executeUpdate();
		} finally {
			// Avoid leak if an exception was thrown in createStatement
			if (st == null) {
				con.close();
			}
		}
	}

	public void updateContinent(ContinentDTO continent) throws SQLException {
		String sql = "update continent set name=? where id=?";

		PreparedStatement st = con.prepareStatement(sql);
		try {
			st.setString(1, continent.getName());
			st.setInt(2, continent.getId());
			st.executeUpdate();
		} finally {
			// Avoid leak if an exception was thrown in createStatement
			if (st == null) {
				con.close();
			}
		}
	}

	public void deleteContinent(int id) throws SQLException {
		String sql = "delete from continent where id=?";

		PreparedStatement st = con.prepareStatement(sql);
		try {
			st.setInt(1, id);
			st.executeUpdate();
		} finally {
			// Avoid leak if an exception was thrown in createStatement
			if (st == null) {
				con.close();
			}
		}
	}

}
